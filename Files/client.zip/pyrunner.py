# INFO: #
# Only here because I didn't want to put run() at the end of Bcloud
# just because I'd like to run it and test each method individually.
# ===================================

import Bcloud
Bcloud.run()

'''
Exciting. Satisfying. Period.
.
'''
